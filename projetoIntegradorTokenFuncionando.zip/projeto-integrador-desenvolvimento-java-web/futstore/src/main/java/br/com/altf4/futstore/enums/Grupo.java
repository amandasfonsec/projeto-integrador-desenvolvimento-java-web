package br.com.altf4.futstore.enums;

public enum Grupo {
	ADMINISTRADOR, ESTOQUISTA
}
