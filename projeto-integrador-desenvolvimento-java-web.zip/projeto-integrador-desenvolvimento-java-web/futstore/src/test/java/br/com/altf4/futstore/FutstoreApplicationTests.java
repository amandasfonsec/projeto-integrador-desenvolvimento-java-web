package br.com.altf4.futstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FutstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
