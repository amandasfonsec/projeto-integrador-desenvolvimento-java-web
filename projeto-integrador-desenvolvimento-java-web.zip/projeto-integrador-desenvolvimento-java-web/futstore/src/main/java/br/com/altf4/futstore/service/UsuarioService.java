package br.com.altf4.futstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import br.com.altf4.futstore.dto.UsuarioDTO;
import br.com.altf4.futstore.model.Usuario;
import br.com.altf4.futstore.repository.IUsuario;
import br.com.altf4.futstore.security.Token;
import br.com.altf4.futstore.security.TokenUtil;
import jakarta.validation.Valid;

@Service
public class UsuarioService {
    private IUsuario repository;
    private PasswordEncoder passwordEncoder;

    @Autowired
    public UsuarioService(IUsuario repository, PasswordEncoder passwordEncoder) {
        this.repository = repository;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    public List<Usuario> listarUsuario() {
        List<Usuario> lista = repository.findAll();
        return lista;
    }

    public Usuario criarUsuario(Usuario usuario) {
        String encoder = this.passwordEncoder.encode(usuario.getSenha());
        usuario.setSenha(encoder);
        Usuario usuarioNovo = repository.save(usuario);
        return usuarioNovo;
    }

    public Usuario editarUsuario(Usuario usuario) {
        String encoder = this.passwordEncoder.encode(usuario.getSenha());
        usuario.setSenha(encoder);
        Usuario usuarioNovo = repository.save(usuario);
        return usuarioNovo;
    }

    public boolean excluirUsuario(Integer id) {
        repository.deleteById(id);
        return true;
    }

    public boolean validarSenha(Usuario usuario) {
        String senha = repository.findById(usuario.getId()).get().getSenha();
        boolean valid = passwordEncoder.matches(usuario.getSenha(), senha);
        return valid;
    }

    public Token gerarToken(@Valid UsuarioDTO usuarioDTO) {
        Usuario user = repository.findByNomeOrEmail(usuarioDTO.getNome(), usuarioDTO.getEmail());
    
        if (user == null) {
            System.out.println("Usuário não encontrado!");
            return null; // Vai gerar 403 no controller
        }
    
        System.out.println("Usuário encontrado: " + user.getNome());
        
        boolean senhaCorreta = passwordEncoder.matches(usuarioDTO.getSenha(), user.getSenha());
    
        if (!senhaCorreta) {
            System.out.println("Senha inválida!");
            return null; // Vai gerar 403 no controller
        }
    
        System.out.println("Usuário autenticado com sucesso!");
    
        return new Token(TokenUtil.createToken(user));
    }

}
