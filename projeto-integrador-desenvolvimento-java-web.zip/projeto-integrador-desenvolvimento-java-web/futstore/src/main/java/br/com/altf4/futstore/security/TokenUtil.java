package br.com.altf4.futstore.security;

import java.security.Key;
import java.util.Collections;
import java.util.Date;

import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties.Authentication;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import br.com.altf4.futstore.model.Usuario;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Validation;

public class TokenUtil {
    private static final String HEADER = "Authorization";
    private static final String PREFIX = "Bearer ";
    private static final long EXPIRATION = 12*60*60*1000;
    private static final String SECRET_KEY = "futstorealtf4!2025#SecureKey1234#";
    private static final String EMISSOR = "Futstore";

    //Cria o token para o usuário
    public static String createToken (Usuario usuario){
        Key secretKey = Keys.hmacShaKeyFor(SECRET_KEY.getBytes());

        String token = Jwts.builder()
            .setSubject(usuario.getNome())
            .setIssuer(EMISSOR)
            .setExpiration(new Date(System.currentTimeMillis()+EXPIRATION))
            .signWith(secretKey, SignatureAlgorithm.HS256)
            .compact();
        
            return PREFIX + token;
        
    }

    //Valida o token
    private static boolean isExpirationValid(Date expiration){
        return expiration.after(new Date(System.currentTimeMillis()));
    }

    private static boolean isEmissorValid(String emissor){
        return EMISSOR.equals(emissor);
    }

    private static boolean isSubjectValid(String username){
        return username != null && username.length() > 0;
    }

    public static UsernamePasswordAuthenticationToken validate(HttpServletRequest request) {
        String token = request.getHeader(HEADER);
    
        if (token == null || !token.startsWith(PREFIX)) {
            return null; // Evita erro caso o token seja inválido
        }
    
        token = token.replace(PREFIX, "");
    
        Jws<Claims> jwsClaims = Jwts.parserBuilder()
                                    .setSigningKey(SECRET_KEY.getBytes())
                                    .build()
                                    .parseClaimsJws(token);
    
        String username = jwsClaims.getBody().getSubject();
        String issuer = jwsClaims.getBody().getIssuer();
        Date expiration = jwsClaims.getBody().getExpiration();
    
        if (isSubjectValid(username) && isEmissorValid(issuer) && isExpirationValid(expiration)) {
            
            return new UsernamePasswordAuthenticationToken(username, null, Collections.emptyList());

        }
    
        return null; 
    }
    
}
